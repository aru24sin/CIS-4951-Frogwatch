// volunteerHomeScreen.tsx
import { Ionicons } from "@expo/vector-icons";
import NetInfo from "@react-native-community/netinfo";
import { useRouter } from "expo-router";
import { onAuthStateChanged, signOut } from "firebase/auth";
import { doc, getDoc } from "firebase/firestore";
import React, { useEffect, useState } from "react";
import { Alert, ImageBackground, ScrollView, StyleSheet, Text, TouchableOpacity, View } from "react-native";
import NavigationMenu from "../../components/NavigationMenu";
import { auth, db } from "../firebaseConfig";

export default function VolunteerHomeScreen() {
  const router = useRouter();
  const [firstName, setFirstName] = useState<string | null>(null);
  const [lastName, setLastName] = useState<string | null>(null);
  const [menuVisible, setMenuVisible] = useState(false);
  const [isConnected, setIsConnected] = useState<boolean | null>(true);

  // Network status listener
  useEffect(() => {
    const unsubscribe = NetInfo.addEventListener(state => {
      setIsConnected(state.isConnected);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (user) => {
      if (!user) {
        setFirstName(null);
        setLastName(null);
        return;
      }
      try {
        const snap = await getDoc(doc(db, "users", user.uid));
        const data = snap.data() || {};
        const fn = (data.firstName || data.firstname || "").toString().trim();
        const ln = (data.lastName || data.lastname || "").toString().trim();

        if (fn || ln) {
          setFirstName(fn || null);
          setLastName(ln || null);
        } else if (user.displayName) {
          const parts = user.displayName.trim().split(/\s+/);
          setFirstName(parts[0] || null);
          setLastName(parts.slice(1).join(" ") || null);
        } else {
          const local = (user.email || "").split("@")[0];
          setFirstName(local ? local : null);
          setLastName(null);
        }
      } catch (e) {
        console.warn("Profile load failed:", e);
      }
    });
    return () => unsub();
  }, []);

  const fullName =
    [firstName, lastName].filter(Boolean).join(" ") ||
    (firstName || lastName) ||
    "";

  const today = new Date();
  const formattedDate = today.toLocaleDateString("en-US", { weekday: "long", day: "numeric", month: "long" });

  const handleLogout = () => {
    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Logout',
          style: 'destructive',
          onPress: async () => {
            try {
              await signOut(auth);
              router.replace('./landingScreen');
            } catch (error) {
              console.error('Error logging out:', error);
              Alert.alert('Error', 'Failed to logout');
            }
          },
        },
      ]
    );
  };

  const buttons = [
    {
      icon: "radio-button-on" as const,
      label: "Recording",
      route: "./recordScreen",
    },
    {
      icon: "bookmark" as const,
      label: "History",
      route: "./historyScreen",
    },
    {
      icon: "map" as const,
      label: "Map",
      route: "./mapHistoryScreen",
    },
    {
      icon: "person-circle" as const,
      label: "Profile",
      route: "./profileScreen",
    },
    {
      icon: "settings" as const,
      label: "Settings",
      route: "./settingsScreen",
    },
  ];

  return (
    <ImageBackground source={require("../../assets/images/homeBackground.png")} style={styles.background} resizeMode="cover">
      <NavigationMenu isVisible={menuVisible} onClose={() => setMenuVisible(false)} />
      
      <ScrollView contentContainerStyle={styles.scrollContainer} showsVerticalScrollIndicator={false}>
        <View style={styles.overlay}>
          {/* Header with logout and menu buttons */}
          <View style={styles.header}>
            <TouchableOpacity onPress={handleLogout} style={styles.iconButton}>
              <Ionicons name="log-out-outline" size={24} color="#fff" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => setMenuVisible(true)} style={styles.iconButton}>
              <Ionicons name="menu" size={28} color="#fff" />
            </TouchableOpacity>
          </View>

          <View>
            <Text style={styles.hello}>Hello{fullName ? `, ${fullName}` : ","}</Text>
            <Text style={styles.date}>{formattedDate}</Text>
            <View style={styles.roleBadge}>
              <Text style={styles.roleText}>Volunteer</Text>
            </View>
          </View>

          <View style={styles.bottomSection}>
            <Text style={styles.status}>
              Status:{" "}
              <Text style={{ color: isConnected ? "#4CAF50" : "#FF6B6B" }}>
                {isConnected ? "Online" : "Offline"}
              </Text>
            </Text>

            <View style={styles.grid}>
              {buttons.slice(0, 3).map((button, index) => (
                <TouchableOpacity
                  key={index}
                  style={styles.button}
                  onPress={() => router.push(button.route as any)}
                >
                  <Ionicons name={button.icon} size={28} color="#ccff00" />
                  <Text style={styles.buttonText}>{button.label}</Text>
                </TouchableOpacity>
              ))}
              {buttons.slice(3).map((button, index) => (
                <TouchableOpacity
                  key={index + 3}
                  style={styles.buttonWide}
                  onPress={() => router.push(button.route as any)}
                >
                  <Ionicons name={button.icon} size={28} color="#ccff00" />
                  <Text style={styles.buttonText}>{button.label}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </View>
      </ScrollView>
    </ImageBackground>
  );
}

const styles = StyleSheet.create({
  background: { flex: 1, width: "100%", height: "100%" },
  scrollContainer: { flexGrow: 1 },
  overlay: { flex: 1, paddingTop: 50, paddingHorizontal: 24, paddingBottom: 40, justifyContent: "space-between" },
  
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 10,
  },
  iconButton: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: 'rgba(0, 0, 0, 0.3)',
    alignItems: 'center',
    justifyContent: 'center',
  },

  hello: { marginTop: 10, fontSize: 32, fontWeight: "400", color: "#f2f2f2ff" },
  date: { fontSize: 30, fontWeight: "500", color: "#ccff00", marginBottom: 8 },
  
  roleBadge: {
    alignSelf: 'flex-start',
    backgroundColor: '#4CAF50',
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 16,
    marginTop: 4,
    marginBottom: 320,
  },
  roleText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#fff',
  },

  bottomSection: { marginTop: 20 },
  status: { fontSize: 18, color: "#ffffffff", marginBottom: 20 },
  grid: { flexDirection: "row", flexWrap: "wrap", justifyContent: "space-between" },
  button: {
    width: "32%",
    height: 90,
    backgroundColor: "rgba(47, 66, 51, 0.9)",
    borderRadius: 20,
    marginBottom: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonWide: {
    width: "48.5%",
    height: 90,
    backgroundColor: "rgba(47, 66, 51, 0.9)",
    borderRadius: 20,
    marginBottom: 8,
    justifyContent: "center",
    alignItems: "center",
  },
  buttonText: { marginTop: 6, fontSize: 18, color: "#ffffffff" },
});
